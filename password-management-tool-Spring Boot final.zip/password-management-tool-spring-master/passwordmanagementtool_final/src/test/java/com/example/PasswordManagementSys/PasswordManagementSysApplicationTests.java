package com.example.PasswordManagementSys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasswordManagementSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
