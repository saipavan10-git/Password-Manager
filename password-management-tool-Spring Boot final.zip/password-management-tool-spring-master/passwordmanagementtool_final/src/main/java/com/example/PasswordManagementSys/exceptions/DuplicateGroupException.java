package com.example.PasswordManagementSys.exceptions;

public class DuplicateGroupException extends Exception {
    public DuplicateGroupException(String s){
        super(s);
    }
}
